import boto3
import json
import os

def lambda_handler(event, context):
    ec2 = boto3.client('ec2')
    instance_id = os.environ['INSTANCE_ID']
    action = event.get('action', 'stop')
    
    try:
        if action == 'stop':
            response = ec2.stop_instances(InstanceIds=[instance_id])
            print(f"Stopping instance {instance_id}")
        elif action == 'start':
            response = ec2.start_instances(InstanceIds=[instance_id])
            print(f"Starting instance {instance_id}")
        
        return {
            'statusCode': 200,
            'body': json.dumps(f'Successfully {action}ped instance {instance_id}')
        }
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error {action}ping instance: {str(e)}')
        }
